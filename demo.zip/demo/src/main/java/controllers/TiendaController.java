package controllers;

import eu.hansolo.fx.countries.CountryPane;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import models.Videojuego;
import org.example.demo.BBDD;

import java.util.ArrayList;

public class TiendaController {
    @FXML
    private VBox videojuegosContainer;

    @FXML
    public void initialize(CountryPane videojuegosContainer) throws InterruptedException {
        System.out.println("Inicializando TiendaController...");

        if (videojuegosContainer == null) {
            System.out.println("❌ VBox no inyectado");
            return;
        }

        ArrayList<Videojuego> listaVideojuegos = BBDD.getListaVideojuegos(0);
        System.out.println("✅ Videojuegos cargados: " + listaVideojuegos.size());

        for (Videojuego juego : listaVideojuegos) {
            Button btn = new Button(juego.getNombre_videojuego());
            btn.setPrefWidth(300);
            btn.setStyle("-fx-background-color: #a100ff; -fx-text-fill: white;");
            videojuegosContainer.getChildren().add(btn);
        }
    }
}

// IMPRIMIR LISTA DE VIDEOJUEGOS
        /*
        for (int i = 0; i < listaVideojuegos.size(); i++) {
            System.out.println("ID     : " + listaVideojuegos.get(i).getId_videojuego());
            System.out.println("Nombre : " + listaVideojuegos.get(i).getNombre_videojuego());
            System.out.println("Precio : " + listaVideojuegos.get(i).getPrecio() + " €");
            System.out.println("CATEGORIAS");

            for (int j = 0; j < listaVideojuegos.get(i).getCategorias().size(); j++) {
                System.out.println("- " + listaVideojuegos.get(i).getCategorias().get(j));
            }

            System.out.println();
        }

         */